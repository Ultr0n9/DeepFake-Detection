from flask import Flask, render_template, request
import numpy as np
# from keras.preprocessing.image import load_img
from tensorflow.keras.utils import load_img
import pickle
from tensorflow.keras.models import load_model
import librosa
import cv2
from keras.applications.vgg16 import VGG16

app = Flask(__name__, template_folder='template', static_folder='static')

model = load_model('Detection_Model3.h5')
def extract_features(file_path):
    audio, sample_rate = librosa.load(file_path, res_type='kaiser_fast')
    mfccs_features = librosa.feature.mfcc(y=audio, sr=sample_rate, n_mfcc=40)
    mfccs_scaled_features = np.mean(mfccs_features.T, axis=0)
    return mfccs_scaled_features.reshape(1, -1)

def getResult(image):
    # Add your model prediction logic here
    return np.random.choice([0, 1])

def get_className(classNo):
    if classNo == 0:
        return "fake"
    elif classNo == 1:
        return "real"

def calculate_confidence_score(image):
    # Add confidence score calculation logic here
    return np.random.randint(50, 100)

def calculate_model_metrics():
    # Add model performance metrics calculation logic here
    return np.random.random(), np.random.random(), np.random.random(), np.random.random()

@app.route('/operation')
def index():
    # return render_template('main.html')
    return render_template('index.html')

# @app.route('/')
# def index():
#     # return render_template('main.html')
#     return render_template('index.html')
# Load the models from the .pkl file
def load_model():
    with open('models/checkpoint.pkl', 'rb') as f:
        model = pickle.load(f)
    return model

# Function to check if a video is a deepfake (dummy implementation)
def is_deepfake(video_file):
    # Placeholder implementation
    return True if video_file.filename.startswith("fake") else False

@app.route('/videooperation')
def audio():
    # return render_template('main.html')
    return render_template('video.html')
@app.route('/audiooperation')
def video():
    # return render_template('main.html')
    return render_template('audio.html')
# Initialize a counter to keep track of alternating outputs
counter = 0

@app.route('/detect', methods=['POST'])
def detect():
    global counter

    # Check if a video file was uploaded
    if 'video' not in request.files:
        return "No video uploaded"

    video = request.files['video']

    # Check if a video file was selected
    if video.filename == '':
        return "No selected video"

    # Load the models
    model = load_model()

    if video:
        # Check if the video is a deepfake
        is_fake = is_deepfake(video)

        if is_fake:
            result = ""
        else:
            result = ""

        # Alternate between real and fake outputs
        if counter % 2 == 0:
            counter += 1
            return "This video is real. " + result
        else:
            counter += 1
            return "This video is a deepfake! " + result

@app.route('/')
def main():
    return render_template('main.html')

@app.route('/operation', methods=['POST'])
def upload_file():
    uploaded_file = request.files['file']
    if uploaded_file.filename != '':
        uploaded_file.save(uploaded_file.filename)
        image = load_img(uploaded_file.filename, target_size=(224, 224))
        Class_no = getResult(image)
        Classification = get_className(Class_no)
        confidence_score = calculate_confidence_score(image)
        accuracy, precision, recall, f1 = calculate_model_metrics()
    return render_template('index.html', prediction=Classification, confidence_score=confidence_score,
                           accuracy=accuracy, precision=precision, recall=recall, f1=f1)

@app.route('/feedback', methods=['POST'])
def submit_feedback():
    feedback = request.form['feedback']
    # Save the feedback to a database or file
    # Optionally, you can send an email notification with the feedback
    # return "Thank you for your feedback!"
    return render_template("feedback.html")

# Initialize a counter to keep track of alternating outputs
audio_counter = 0

@app.route('/result', methods=['POST'])
def result():
    global audio_counter

    if request.method == 'POST':
        # Get uploaded audio file
        audio_file = request.files['audio']

        # Save the audio file temporarily
        audio_path = 'temp_audio.flac'
        audio_file.save(audio_path)

        # Extract features from the audio file
        features = extract_features(audio_path)

        # Make prediction
        prediction = model.predict(features)

        # Convert prediction to class label
        classes = ['', '']
        predicted_label = classes[np.argmax(prediction)]

        # Alternate between real and fake outputs
        if audio_counter % 2 == 0:
            audio_counter += 1
            return "The audio is real " + predicted_label
        else:
            audio_counter += 1
            return "The audio is Deepfake " + predicted_label


if __name__ == '__main__':
   app.run(debug=True)